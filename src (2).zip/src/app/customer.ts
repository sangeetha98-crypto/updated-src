export class Customer {
     customerId:string="";
     customerName:string=""; 
     userName:string=""; 
     password:string=""; 
     city:string="";
     phoneNo:string=""; 
     emailId:string="";  
}
