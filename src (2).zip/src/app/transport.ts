export class Transport {
    transportId:string="";
    customerId:string="";
    vehicleType:string="";
    driverName:string="";
    driverPhoneNo:string="";
    
}
