import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TransportService } from '../transport.service';

@Component({
  selector: 'app-transport',
  templateUrl: './transport.component.html',
  styleUrls: ['./transport.component.css']
})
export class TransportComponent implements OnInit {
  transportForm:any
  transports:any;
  formGroup:any;
  transportId:any;
  
  
  
    constructor(private fb:FormBuilder,private ts:TransportService) {
      this.transportForm=this.fb.group({
        transportId:['',[Validators.required,Validators.minLength(6),Validators.maxLength(6),Validators.pattern]],
        customerId:['',[Validators.required,Validators.minLength(6),Validators.maxLength(6), Validators.pattern ]],
        vehicleType:[''],
        driverName:[''],
         driverPhoneNo:['',[Validators.required,Validators.minLength(10),Validators.maxLength(10),Validators.pattern]]
      },{validators:this.transportIdValidator()});
  
    }

transportIdValidator() {
    return (formGroup: FormGroup) => {
      if (formGroup.controls.transportId.errors && !formGroup.controls.transportId.errors.transportIdValidator)
        return;
      var status =false;
      var transportId= formGroup.controls.transportId.value;
      //alert(transportId.substring(0,1));
      if (transportId.substring(0, 1) != 'T') {
        status = true;
      } else {
        var num = transportId.substring(1);
        if (isNaN(num))
          status = true;
      }
      if (status)
        formGroup.controls.transportId.setErrors({ 'transportIdValidator': true });
      else
        formGroup.controls.transportId.setErrors(null);
    }
  }
  // customerIdValidator() {
  //   return (formGroup: FormGroup) => {
  //     if (formGroup.controls.customerId.errors && !formGroup.controls.customerId.errors.customerIdValidator)
  //       return;
  //     var status =false;
  //     var customerId= formGroup.controls.customerId.value;
  //     //alert(transportId.substring(0,1));
  //     if (customerId.substring(0, 1) != 'C') {
  //       status = true;
  //     } else {
  //       var num = customerId.substring(1);
  //       if (isNaN(num))
  //         status = true;
  //     }
  //     if (status)
  //       formGroup.controls.customerId.setErrors({ 'customerIdValidator': true });
  //     else
  //       formGroup.controls.customerId.setErrors(null);
  //   }
  // }
  
  

  ngOnInit(): void {
    this.getAllTransports();
    
  }
  
     getAllTransports()
     {
       this.ts.getAllTransports().subscribe((data)=>{
        console.log(data);
        this.transports=data;
       });
     }
  
  
       fnFind()
       {
         var transportId=this.transportForm.controls.transportId.value;
         this.ts.findTransportById(transportId).subscribe((data)=>{
           console.log(data);
           //alert(JSON.stringify(data));
           this.transportForm.patchValue(data);//to get all data when od is given
           
         });
       }
       fnAdd()
       {
         var transport=this.transportForm.value;
         this.ts.addTransport(transport).subscribe((data)=>{
           console.log(data);
           this.getAllTransports();
         });
         
       }
        fnModify()
        {
          var transport=this.transportForm.value;
         this.ts.modifyTransport(transport).subscribe((data)=>{
           console.log(data); 
           this.getAllTransports();
          //alert("Modifying")
          
         });
        }
        fnDelete()
        {
         var transportId=this.transportForm.controls.transportId.value;
          this.ts.deleteTransport(transportId).subscribe((data)=>{
          console.log(data);
          this.getAllTransports();
          //alert("deleting")
          
        });
      }
    
    get form()
    {
      return this.transportForm.controls;
    }
    
    
    }
  